function openDrawer() {
    document.getElementById("sideNav").style.width = "80%";
}

function closeDrawer() {
    document.getElementById("sideNav").style.width = "0";
}