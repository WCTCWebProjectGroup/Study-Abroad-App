// Global Variables go in this file
// All functions queued up cannot accept parameters
// When linking this file, make sure it's the first script in the header
function GlobalVars () {
    var queue = [];
    function addToQueue() {

    }
}